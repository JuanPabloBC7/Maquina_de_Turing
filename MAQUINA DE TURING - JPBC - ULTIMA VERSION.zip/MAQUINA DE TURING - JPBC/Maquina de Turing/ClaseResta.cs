﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maquina_de_Turing
{
    class ClaseResta
    {
        public string Dato;
        public int PosicionActual;
        public int i = 1;
        public DataGridView DGV;
        public ListBox TextArea;
        public int Tiempo;

        public void Variables(string Dato2, DataGridView DGV2, ListBox listBox, int PosicionInicial)
        {
            Dato = Dato2;
            DGV = DGV2;
            TextArea = listBox;
            PosicionActual = PosicionInicial;

            string Valor = DGV.Rows[0].Cells[PosicionActual].Value.ToString();

            q0(Valor);
        }

        public void q0(string ValorActual)
        {
            switch (ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q0,          Transicion: (q1, X, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "X"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q1(ValorActual);
                    break;
                case "-":
                    MessageBox.Show("Se esperaba un 1 antes del signo -", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "=":
                    MessageBox.Show("Se esperaba un 1-1 antes del signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, -, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q1(string ValorActual)
        {
            switch (ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q1,          Transicion: (q1, 1, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "1"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q1(ValorActual);
                    break;
                case "-":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q1,          Transicion: (q2, -, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "-"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q2(ValorActual);
                    break;
                case "=":
                    MessageBox.Show("Se esperaba un 1 antes del signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, -, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q2(string ValorActual)
        {
            switch (ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q2,          Transicion: (q3, B, L)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q3(ValorActual);
                    break;
                case "-":
                    MessageBox.Show("No se puede repetir el signo -", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "=":
                    MessageBox.Show("Se esperaba un 1 antes del signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, -, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q3(string ValorActual)
        {
            switch (ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q3,          Transicion: (q3, 1, L)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "1"; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q3(ValorActual);
                    break;
                case "-":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q3,          Transicion: (q3, -, L)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "-"; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q3(ValorActual);
                    break;
                case "=":
                    MessageBox.Show("Se espera un 1 antes del signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "X":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q3,          Transicion: (q4, B, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q4(ValorActual);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q3,          Transicion: (q3, B, L)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q3(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, -, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q4(string ValorActual)
        {
            switch (ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q4,          Transicion: (q5, X, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "X"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q5(ValorActual);
                    break;
                case "-":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q4,          Transicion: (q7, 0, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "0"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q7(ValorActual);
                    break;
                case "=":
                    MessageBox.Show("Se espera un 1 antes del signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "X":
                    MessageBox.Show("Se esperaba eliminar X", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "":
                    MessageBox.Show("No se esperaba un B", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, -, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q5(string ValorActual)
        {
            switch (ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q5,          Transicion: (q5, 1, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "1"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q5(ValorActual);
                    break;
                case "-":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q5,          Transicion: (q6, -, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "-"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q6(ValorActual);
                    break;
                case "=":
                    MessageBox.Show("Se espera un 1 antes del signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "X":
                    MessageBox.Show("Se esperaba eliminar X", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "":
                    MessageBox.Show("No se esperaba un B", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, -, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q6(string ValorActual)
        {
            switch (ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q6,          Transicion: (q3, B, L)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q3(ValorActual);
                    break;
                case "-":
                    MessageBox.Show("No se esperaba un signo -", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "=":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q6,          Transicion: (q8, B, L)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q8(ValorActual);
                    break;
                case "X":
                    MessageBox.Show("No se esperaba un signo X", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q6,          Transicion: (q6, B, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q6(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, -, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q7(string ValorActual)
        {
            switch (ValorActual)
            {
                case "1":
                    MessageBox.Show("No se esperaba un signo 1", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "-":
                    MessageBox.Show("No se esperaba un signo -", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "=":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q7,          Transicion: (q100, B, L)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q100(ValorActual);
                    break;
                case "X":
                    MessageBox.Show("No se esperaba un signo X", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q7,          Transicion: (q7, B, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q7(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, -, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q8(string ValorActual)
        {
            switch (ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q8,          Transicion: (q8, 1, L)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "1"; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q8(ValorActual);
                    break;
                case "-":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q8,          Transicion: (q8, B, L)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q8(ValorActual);
                    break;
                case "=":
                    MessageBox.Show("No se esperaba un signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "X":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q8,          Transicion: (q100, 1, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "1"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q100(ValorActual);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q8,          Transicion: (q8, B, L)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q8(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, -, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }


        public void q100(string ValorActual)
        {
            TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q100,        No Hay Transiciones: Estado de Aceptacion");
            DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;//Actual Pinto Blanco
            MessageBox.Show("Resta realizada con exito", "RESTA EXITOSA", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
