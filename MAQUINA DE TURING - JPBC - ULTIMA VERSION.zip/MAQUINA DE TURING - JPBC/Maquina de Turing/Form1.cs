﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maquina_de_Turing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DataGridViewTextBoxColumn Columna1 = new DataGridViewTextBoxColumn();
        public int Conteo;
        public int PosicionInicial = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string Dato = textBox1.Text.Replace(" ", "");
                Regex ABC = new Regex(@"[abc]+[=]"); Regex SUM = new Regex(@"[1]+[\\+][1]+[=]"); Regex RES = new Regex(@"[1]+[-][1]+[=]"); Regex MULT = new Regex(@"[1]+[*][1]+[=]");
                int CaracterActual;
                char CharActual;

                if (!Dato.Contains("="))
                {
                    Dato += "=";
                }

                for (int i = 0; i < Dato.Length; i++)
                {
                    CaracterActual = Dato[i];
                    CharActual = (char)CaracterActual;

                    //dataGridView1.Rows[1].Cells[0].Style.BackColor = Color.Gold; //Inserto Color en celda 
                    //dataGridView1.Rows[0].Cells[0].Value = "HOLA"; //Cambio el valor de la celda
                    DGV.Columns.Add("Columna" + i, i.ToString());
                    DGV.Rows[0].Cells[i].Value = CharActual.ToString();
                    DGV.Columns[i].Width = 30;
                }
                DGV.Rows[0].Cells[0].Style.BackColor = Color.Aqua;

                if (radioButton1.Checked && !textBox1.Text.Equals(""))
                {
                    PosicionInicial = 0;
                    ClaseSuma CS = new ClaseSuma();
                    CS.Variables(Dato, DGV, listBox1, PosicionInicial);
                }
                else if (radioButton2.Checked && !textBox1.Text.Equals(""))
                {
                    PosicionInicial = 0;
                    ClaseResta CR = new ClaseResta();
                    CR.Variables(Dato, DGV, listBox1, PosicionInicial);
                }
                else if(radioButton3.Checked && !textBox1.Text.Equals(""))
                {
                    PosicionInicial = 0;
                    ClaseMultiplicar CM = new ClaseMultiplicar();
                    CM.Variables(Dato, DGV, listBox1, PosicionInicial);
                }
                else if (radioButton4.Checked && !textBox1.Text.Equals(""))
                {
                    PosicionInicial = 0;
                    ClasePalindromo CP = new ClasePalindromo();
                    CP.Variables(Dato, DGV, listBox1, PosicionInicial);
                }
                else if (radioButton5.Checked && !textBox1.Text.Equals(""))
                {
                    PosicionInicial = 0;
                    ClaseCopiaPatrones CC = new ClaseCopiaPatrones();
                    CC.Variables(Dato, DGV, listBox1, PosicionInicial);
                }
                else
                {
                    MessageBox.Show("No selecciono una operacion \nCadena mal escrita", "ERROR", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("Boton Ingresar Catch", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult Respuesta = MessageBox.Show("Desea continuar", "PREGUNTA", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Respuesta == DialogResult.Yes)
            {
                textBox1.Text = "";
                listBox1.Items.Clear();
                DGV.Columns.Clear();
            }
        }
    }
}
