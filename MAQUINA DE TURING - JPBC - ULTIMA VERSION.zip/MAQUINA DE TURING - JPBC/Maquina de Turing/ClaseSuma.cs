﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Maquina_de_Turing
{
    class ClaseSuma
    {
        public string Dato;
        public int PosicionActual;
        public int i = 1; 
        public DataGridView DGV;
        public ListBox TextArea;
        
        public void Variables(string Dato2, DataGridView DGV2, ListBox listBox, int PosicionInicial)
        {
            Dato = Dato2;
            DGV = DGV2;
            TextArea = listBox;
            PosicionActual = PosicionInicial;

            string Valor = DGV.Rows[0].Cells[PosicionActual].Value.ToString();

            q0(Valor);
        }
        
        public void q0 (string ValorActual)
        {
            switch(ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q0,          Transicion: (q1, B, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; //Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; //Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q1(ValorActual);
                    break;
                case "+":
                    MessageBox.Show("Se esperaba un 1 antes del signo +", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "=":
                    MessageBox.Show("Se esperaba un 1 antes del signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, +, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q1 (string ValorActual)
        {
            switch(ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q1,          Transicion: (q1, 1, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;//Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "1";//Convierto En
                    PosicionActual++; i++;//Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;//Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q1(ValorActual);
                    break;
                case "+":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q1,          Transicion: (q2, 1, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;//Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "1";//Convierto En
                    PosicionActual++; i++;//Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;//Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q2(ValorActual);
                    break;
                case "=":
                    MessageBox.Show("Se esperaba un +1 antes del signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, +, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q2(string ValorActual)
        {
            switch (ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q2,          Transicion: (q3, 1, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;//Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "1";//Convierto En
                    PosicionActual++; i++;//Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;//Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion 
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q3(ValorActual);
                    break;
                case "+":
                    MessageBox.Show("Se esperaba un 1 despues del signo +", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "=":
                    MessageBox.Show("Se esperaba un 1 antes del signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, +, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q3(string ValorActual)
        {
            switch (ValorActual)
            {
                case "1":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q3,          Transicion: (q3, 1, R)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;//Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "1";//Convierto En
                    PosicionActual++; i++;//Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;//Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q3(ValorActual);
                    break;
                case "+":
                    MessageBox.Show("No se esperaba un signo +", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "=":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q3,          Transicion: (q100, B, L)");
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;//Actual Pinto Blanco
                    DGV.Rows[0].Cells[PosicionActual].Value = "";//Convierto En
                    PosicionActual--; i++;//Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;//Cambio Posicion Siguiente
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();//Cambio Posicion Siguiente
                    DGV.Refresh();
                    Thread.Sleep(500);
                    q100(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(1, +, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q100(string ValorActual)
        {
            TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q100,        No Hay Transiciones: Estado de Aceptacion");
            DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;//Actual Pinto Blanco
            MessageBox.Show("Suma realizada con exito", "SUMA EXITOSA", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    //int hola = DGV.ColumnCount;
    //MessageBox.Show("Resta");
    //DGV.Columns.Add("Columna" + hola, hola.ToString());
    //DGV.Columns[hola].Width = 30;
    //MessageBox.Show("Resta");
}


public class AutoClosingMessageBox
{
    System.Threading.Timer _timeoutTimer;
    string _caption;
    AutoClosingMessageBox(string text, string caption, int timeout)
    {
        _caption = caption;
        _timeoutTimer = new System.Threading.Timer(OnTimerElapsed,
            null, timeout, System.Threading.Timeout.Infinite);
        using (_timeoutTimer)
            MessageBox.Show(text, caption);
    }
    public static void Show(string text, string caption, int timeout)
    {
        new AutoClosingMessageBox(text, caption, timeout);
    }
    void OnTimerElapsed(object state)
    {
        IntPtr mbWnd = FindWindow("#32770", _caption); // lpClassName is #32770 for MessageBox
        if (mbWnd != IntPtr.Zero)
            SendMessage(mbWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
        _timeoutTimer.Dispose();
    }
    const int WM_CLOSE = 0x0010;
    [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
    static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
    [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
    static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);
}
