﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maquina_de_Turing
{
    class ClasePalindromo
    {
        public string Dato;
        public int PosicionActual;
        public int i = 1;
        public DataGridView DGV;
        public ListBox TextArea;

        public void Variables(string Dato2, DataGridView DGV2, ListBox listBox, int PosicionInicial)
        {
            Dato = Dato2;
            DGV = DGV2;
            TextArea = listBox;
            PosicionActual = PosicionInicial;

            string Valor = DGV.Rows[0].Cells[PosicionActual].Value.ToString();

            q0(Valor);
        }

        public void q0(string ValorActual)
        {
            switch (ValorActual)
            {
                case "a":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q0,          Transicion: (q1, a, R)");
                    AutoClosingMessageBox.Show("(q1, a, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; 
                    DGV.Rows[0].Cells[PosicionActual].Value = "a"; //Convierto 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; 
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q1(ValorActual);
                    break;
                case "b":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q0,          Transicion: (q1, b, R)");
                    AutoClosingMessageBox.Show("(q1, b, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "b"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q1(ValorActual);
                    break;
                case "c":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q0,          Transicion: (q1, c, R)");
                    AutoClosingMessageBox.Show("(q1, c, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "c"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q1(ValorActual);
                    break;
                case "=":
                    MessageBox.Show("Se esperaba un signo a, b ó c antes del signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q1,          Transicion: (q12, B, R)");
                    AutoClosingMessageBox.Show("(q12, B, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q12(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q1(string ValorActual)
        {
            switch (ValorActual)
            {
                case "a":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q1,          Transicion: (q2, a, L)");
                    AutoClosingMessageBox.Show("(q2, a, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "a"; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q2(ValorActual);
                    break;
                case "b":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q1,          Transicion: (q2, b, L)");
                    AutoClosingMessageBox.Show("(q2, b, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; 
                    DGV.Rows[0].Cells[PosicionActual].Value = "b"; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; 
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q2(ValorActual);
                    break;
                case "c":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q1,          Transicion: (q2, c, L)");
                    AutoClosingMessageBox.Show("(q2, c, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White; 
                    DGV.Rows[0].Cells[PosicionActual].Value = "c"; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua; 
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q2(ValorActual);
                    break;
                case "=":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q1,          Transicion: (q100, B, L)");
                    AutoClosingMessageBox.Show("(q100, B, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q100(ValorActual);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q1,          Transicion: (q12, B, R)");
                    AutoClosingMessageBox.Show("(q12, B, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q12(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q2(string ValorActual)
        {
            switch (ValorActual)
            {
                case "a":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q2,          Transicion: (q3, X, R)");
                    AutoClosingMessageBox.Show("(q3, X, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "X"; //Convierto 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q3(ValorActual);
                    break;
                case "b":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q2,          Transicion: (q6, X, R)");
                    AutoClosingMessageBox.Show("(q6, X, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "X"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q6(ValorActual);
                    break;
                case "c":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q2,          Transicion: (q9, X, R)");
                    AutoClosingMessageBox.Show("(q9, X, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "X"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q9(ValorActual);
                    break;
                case "=":
                    MessageBox.Show("No se esperaba un signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q3(string ValorActual)
        {
            switch (ValorActual)
            {
                case "a":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q3,          Transicion: (q3, a, R)");
                    AutoClosingMessageBox.Show("(q3, a, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "a"; //Convierto 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q3(ValorActual);
                    break;
                case "b":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q3,          Transicion: (q3, b, R)");
                    AutoClosingMessageBox.Show("(q3, b, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "b"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q3(ValorActual);
                    break;
                case "c":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q3,          Transicion: (q3, c, R)");
                    AutoClosingMessageBox.Show("(q3, c, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "c"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q3(ValorActual);
                    break;
                case "=":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q3,          Transicion: (q4, =, L)");
                    AutoClosingMessageBox.Show("(q4, =, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "="; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q4(ValorActual);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q3,          Transicion: (q3, B, R)");
                    AutoClosingMessageBox.Show("(q3, B, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q3(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q4(string ValorActual)
        {
            switch (ValorActual)
            {
                case "a":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q4,          Transicion: (q5, B, L)");
                    AutoClosingMessageBox.Show("(q5, B, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q5(ValorActual);
                    break;
                case "b":
                    MessageBox.Show("No se esperaba un signo b", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "c":
                    MessageBox.Show("No se esperaba un signo c", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "=":
                    MessageBox.Show("No se esperaba un signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q4,          Transicion: (q4, B, L)");
                    AutoClosingMessageBox.Show("(q4, B, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q4(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q5(string ValorActual)
        {
            switch (ValorActual)
            {
                case "a":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q5,          Transicion: (q5, a, L)");
                    AutoClosingMessageBox.Show("(q5, a, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "a"; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q5(ValorActual);
                    break;
                case "b":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q5,          Transicion: (q5, b, L)");
                    AutoClosingMessageBox.Show("(q5, b, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "b"; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q5(ValorActual);
                    break;
                case "c":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q5,          Transicion: (q5, c, L)");
                    AutoClosingMessageBox.Show("(q5, c, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "c"; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q5(ValorActual);
                    break;
                case "=":
                    MessageBox.Show("No se esperaba un signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "X":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q5,          Transicion: (q0, B, R)");
                    AutoClosingMessageBox.Show("(q0, B, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q0(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q6(string ValorActual)
        {
            switch (ValorActual)
            {
                case "a":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q6,          Transicion: (q6, a, R)");
                    AutoClosingMessageBox.Show("(q6, a, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "a"; //Convierto 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q6(ValorActual);
                    break;
                case "b":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q6,          Transicion: (q6, b, R)");
                    AutoClosingMessageBox.Show("(q6, b, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "b"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q6(ValorActual);
                    break;
                case "c":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q6,          Transicion: (q6, c, R)");
                    AutoClosingMessageBox.Show("(q6, c, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "c"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q6(ValorActual);
                    break;
                case "=":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q6,          Transicion: (q7, =, L)");
                    AutoClosingMessageBox.Show("(q7, =, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "="; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q7(ValorActual);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q6,          Transicion: (q6, B, R)");
                    AutoClosingMessageBox.Show("(q6, B, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q6(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q7(string ValorActual)
        {
            switch (ValorActual)
            {
                case "b":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q7,          Transicion: (q8, B, L)");
                    AutoClosingMessageBox.Show("(q8, B, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q8(ValorActual);
                    break;
                case "a":
                    MessageBox.Show("No se esperaba un signo a", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "c":
                    MessageBox.Show("No se esperaba un signo c", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "=":
                    MessageBox.Show("No se esperaba un signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q7,          Transicion: (q7, B, L)");
                    AutoClosingMessageBox.Show("(q7, B, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q7(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q8(string ValorActual)
        {
            switch (ValorActual)
            {
                case "a":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q8,          Transicion: (q8, a, L)");
                    AutoClosingMessageBox.Show("(q8, a, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "a"; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q8(ValorActual);
                    break;
                case "b":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q8,          Transicion: (q8, b, L)");
                    AutoClosingMessageBox.Show("(q8, b, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "b"; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q8(ValorActual);
                    break;
                case "c":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q8,          Transicion: (q8, c, L)");
                    AutoClosingMessageBox.Show("(q8, c, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "c"; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q8(ValorActual);
                    break;
                case "=":
                    MessageBox.Show("No se esperaba un signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "X":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q8,          Transicion: (q0, B, R)");
                    AutoClosingMessageBox.Show("(q0, B, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q0(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q9(string ValorActual)
        {
            switch (ValorActual)
            {
                case "a":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q9,          Transicion: (q9, a, R)");
                    AutoClosingMessageBox.Show("(q9, a, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "a"; //Convierto 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q9(ValorActual);
                    break;
                case "b":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q9,          Transicion: (q9, b, R)");
                    AutoClosingMessageBox.Show("(q9, b, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "b"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q9(ValorActual);
                    break;
                case "c":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q9,          Transicion: (q9, c, R)");
                    AutoClosingMessageBox.Show("(q9, c, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "c"; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q9(ValorActual);
                    break;
                case "=":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q9,          Transicion: (q10, =, L)");
                    AutoClosingMessageBox.Show("(q10, =, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "="; //Convierto En 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q10(ValorActual);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q9,          Transicion: (q9, B, R)");
                    AutoClosingMessageBox.Show("(q9, B, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto En 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q9(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q10(string ValorActual)
        {
            switch (ValorActual)
            {
                case "c":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q10,          Transicion: (q11, B, L)");
                    AutoClosingMessageBox.Show("(q11, B, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q11(ValorActual);
                    break;
                case "a":
                    MessageBox.Show("No se esperaba un signo a", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "b":
                    MessageBox.Show("No se esperaba un signo b", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "=":
                    MessageBox.Show("No se esperaba un signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q10,          Transicion: (q10, B, L)");
                    AutoClosingMessageBox.Show("(q10, B, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q10(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q11(string ValorActual)
        {
            switch (ValorActual)
            {
                case "a":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q11,          Transicion: (q11, a, L)");
                    AutoClosingMessageBox.Show("(q11, a, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "a"; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q11(ValorActual);
                    break;
                case "b":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q11,          Transicion: (q11, b, L)");
                    AutoClosingMessageBox.Show("(q11, b, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "b"; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q11(ValorActual);
                    break;
                case "c":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q11,          Transicion: (q11, c, L)");
                    AutoClosingMessageBox.Show("(q11, c, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = "c"; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q11(ValorActual);
                    break;
                case "=":
                    MessageBox.Show("No se esperaba un signo =", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "X":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q11,          Transicion: (q0, B, R)");
                    AutoClosingMessageBox.Show("(q0, B, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q0(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q12(string ValorActual)
        {
            switch (ValorActual)
            {
                case "a":
                    MessageBox.Show("No se esperaba un signo a", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "b":
                    MessageBox.Show("No se esperaba un signo b", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "c":
                    MessageBox.Show("No se esperaba un signo c", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case "=":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q12,          Transicion: (q100, B, L)");
                    AutoClosingMessageBox.Show("(q100, B, L)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto 
                    PosicionActual--; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q100(ValorActual);
                    break;
                case "":
                    TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q12,          Transicion: (q12, B, R)");
                    AutoClosingMessageBox.Show("(q12, B, R)", "Transicion", 500);
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;
                    DGV.Rows[0].Cells[PosicionActual].Value = ""; //Convierto 
                    PosicionActual++; i++; //Cambio Posicion Siguiente
                    DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.Aqua;
                    ValorActual = DGV.Rows[0].Cells[PosicionActual].Value.ToString();
                    q12(ValorActual);
                    break;
                default:
                    MessageBox.Show("Caracter no pertenece al conjunto Γ(a, b, c, =)", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public void q100(string ValorActual)
        {
            TextArea.Items.Add("Paso: " + i + ",        Estado Actual: q100,        No Hay Transiciones: Estado de Aceptacion");
            DGV.Rows[0].Cells[PosicionActual].Style.BackColor = Color.White;//Actual Pinto Blanco
            MessageBox.Show("Si es Palindromo", "PALINDROMO EXITOSO", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
